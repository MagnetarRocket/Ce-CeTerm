#include <stdio.h>

main(){


int t = 1;

for (t = 0; t < 255; t++)
   fprintf(stdout, "%c\n", t);

}









